#!/bin/bash
lxterminal
