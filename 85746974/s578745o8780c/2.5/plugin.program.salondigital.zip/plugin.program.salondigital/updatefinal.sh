#!/bin/bash
/home/htpc/.kodi/addons/plugin.program.salondigital/./update.sh.x
