#! /bin/bash

#Busca procesos llamados hyperiond
pid=`ps --no-heading -C hyperiond | cut -d "?" -f1`;

#Si lo encuentra entonces apaga hyperiond
if [ -n "$pid" ]; then
sudo hyperion-remote -c black && sleep 2 && sudo killall -9 hyperiond

#Si no lo encuentra entonces arranca boblight
else
/usr/bin/hyperiond /etc/hyperion.config.json >/dev/null 2>&1
fi
