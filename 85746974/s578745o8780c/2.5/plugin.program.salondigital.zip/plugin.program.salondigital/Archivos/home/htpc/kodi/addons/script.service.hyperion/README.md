script.service.hyperion
=======================

XBMC addon to capture video data and send it to Hyperion. Note that this plugin will not work for XBMC running on the Raspberry Pi, because the video capture interface is not (yet?) supported on this device.

Information about Hyperion can be found here: https://github.com/tvdzwan/hyperion/wiki

The addon can be installed by downlading the zip and extracting it to the addon directory (probably ~/.xbmc/addons on Linux and C:\Users\user\AppData\Roaming\XBMC\addons on Windows)
