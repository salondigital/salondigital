#!/bin/bash
OUTPUT=`xrandr -display :0 -q | sed '/ connected/!d;s/ .*//;q'`
killall -STOP kodi.bin &
xrandr -display :0 --output $OUTPUT --set "Broadcast RGB" "Limited 16:235" &
## compton --backend glx --paint-on-overlay --glx-no-stencil --vsync opengl-swc &
# compton -CGb --backend glx &
# compton -b --backend glx &
pulseaudio --start &
sudo systemctl stop xboxdrv; sleep 1;
sudo modprobe xpad; sleep 1; steam -bigpicture;
killall -9 steam;
sudo rmmod xpad && 
sudo systemctl start xboxdrv; sleep 1;
pulseaudio -k
## killall -9 compton &
xrandr -display :0 --output $OUTPUT --set "Broadcast RGB" "Full" &
killall -CONT kodi.bin
