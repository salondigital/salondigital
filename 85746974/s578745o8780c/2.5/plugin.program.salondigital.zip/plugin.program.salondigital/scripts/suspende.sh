#! /bin/bash
sudo rm -rf /home/htpc/.salondigital/Apagar.sh
sudo rm -rf /home/htpc/.salondigital/kill_boblight.sh
sudo rm -rf /home/htpc/Documentos/kill_boblight.sh
sleep 1
touch /home/htpc/.salondigital/Apagar.sh
touch /home/htpc/.salondigital/kill_boblight.sh
touch /home/htpc/Documentos/kill_boblight.sh
sleep 1
echo "#! /bin/bash" >> /home/htpc/.salondigital/Apagar.sh
echo "#! /bin/bash" >> /home/htpc/.salondigital/kill_boblight.sh
echo "#! /bin/bash" >> /home/htpc/Documentos/kill_boblight.sh
sleep 1
echo "sudo pm-suspend" >> /home/htpc/.salondigital/Apagar.sh
echo "sudo pm-suspend" >> /home/htpc/.salondigital/kill_boblight.sh
echo "sudo pm-suspend" >> /home/htpc/Documentos/kill_boblight.sh
sleep 1
sudo chmod -R 777 /home/htpc/Documentos/kill_boblight.sh
sudo chmod -R 777 /home/htpc/.salondigital/Apagar.sh
sudo chmod -R 777 /home/htpc/.salondigital/kill_boblight.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hecho!","message":""}}' http://localhost:8080/jsonrpc
