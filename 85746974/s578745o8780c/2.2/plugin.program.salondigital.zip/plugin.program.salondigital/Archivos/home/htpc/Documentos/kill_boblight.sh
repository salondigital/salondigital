#! /bin/bash
sudo systemctl stop LCDd
killall -9 start.sh start2.sh  &
killall boblightd &
killall -9 lirc &
killall -9 kodi.bin &
###/usr/bin/sudo /etc/rc0.d/S01halt stop
sudo poweroff -f
