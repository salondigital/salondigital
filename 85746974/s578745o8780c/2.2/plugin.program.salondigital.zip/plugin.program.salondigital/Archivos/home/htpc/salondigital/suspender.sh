#!/bin/bash
sudo pm-suspend