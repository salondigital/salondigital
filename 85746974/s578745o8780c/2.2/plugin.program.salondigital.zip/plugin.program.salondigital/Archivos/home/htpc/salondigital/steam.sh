#!/bin/bash
killall -STOP kodi.bin &
## compton --backend glx --paint-on-overlay --glx-no-stencil --vsync opengl-swc &
# compton -CGb --backend glx &
# compton -b --backend glx &
##pulseaudio --start &
sudo systemctl stop xboxdrv; sleep 1;
sudo modprobe xpad; sleep 1; LD_PRELOAD='/usr/$LIB/libasound.so.2' ${LD_PRELOAD} steam;
killall -9 steam;
sudo rmmod xpad && 
sudo systemctl start xboxdrv; sleep 1;
###pulseaudio -k
## killall -9 compton &
killall -CONT kodi.bin
