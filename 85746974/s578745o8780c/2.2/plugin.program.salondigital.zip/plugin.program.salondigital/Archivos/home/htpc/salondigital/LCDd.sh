#! /bin/bash
case "$(pidof LCDd | wc -w)" in

0)  echo "Restarting LCDd:     $(date)" >> /home/htpc/.salondigital/log.txt
    sudo systemctl start LCDd &
    ;;
1)  echo "LCDd running, all OK:     $(date)" >> /home/htpc/.salondigital/log.txt
    ;;
*)  echo "Removed double LCDd: $(date)" >> /home/htpc/.salondigital/log.txt
    sudo kill $(pidof LCDd | awk '{print $1}')
    ;;
esac
