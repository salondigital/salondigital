#!/bin/bash
sudo apt-add-repository -y ppa:wsnipex/vaapi
sleep 1
sudo apt-get update
if grep -m1 nvidia "/home/htpc/.config/openbox/gpu.txt"
then
echo ""
else
sudo apt-get install -y i965-va-driver i965-va-driver:i386 vainfo va-driver-all va-driver-all:i386 libva-drm1 libva-drm1:i386 libva-glx1 libva-wayland1 libva-x11-1 libva-x11-1:i386 libva1 libva1:i386
fi 
