#!/bin/bash
killall -STOP kodi.bin &
/opt/urserver/urserver-start --no-manager --no-notify &
# compton -CGb --backend glx &
# compton -b --backend glx &	
pulseaudio --start &
pavucontrol &
LIBGL_DRI3_DISABLE=1 google-chrome --disable-infobars --disable-session-crashed-bubble --ignore-gpu-blacklist "https://www.youtube.com/watch?v=7EPFvJ3Wa9A"
killall -9 pavucontrol
pkill --oldest chrome
pulseaudio -k
## killall -9 compton &
killall -CONT kodi.bin
