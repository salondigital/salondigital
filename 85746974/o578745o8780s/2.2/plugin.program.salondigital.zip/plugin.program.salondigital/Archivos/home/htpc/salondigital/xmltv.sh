#! /bin/bash
sleep 20
rm -rf "/home/htpc/.salondigital/epg/xmltv.xml" && wget -O "/home/htpc/.salondigital/epg/latinmunich_xmltv-movistar-spain.gz" "http://epg.tododream.com/latinmunich_xmltv-movistar-spain.gz" && gunzip -f "/home/htpc/.salondigital/epg/latinmunich_xmltv-movistar-spain.gz" && mv "/home/htpc/.salondigital/epg/latinmunich_xmltv-movistar-spain" "/home/htpc/.salondigital/epg/xmltv.xml" && cat "/home/htpc/.salondigital/epg/xmltv.xml" | nc -w 5 -U /home/hts/.hts/tvheadend/epggrab/xmltv.sock

