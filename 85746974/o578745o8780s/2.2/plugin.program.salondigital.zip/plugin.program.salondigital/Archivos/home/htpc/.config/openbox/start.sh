#!/bin/bash
while [ 1 ] # do forever
do
sleep 2
kodipid=$(pidof kodi.bin)
if [ -z $kodipid ]; then # checks if kodi is running if not..
/usr/bin/sudo cp -R /home/htpc/.salondigital/flix2kodi/strings.po /home/htpc/.kodi/addons/plugin.video.flix2kodi/resources/language/English
kodi &
sudo systemctl start LCDd &
sleep 5
chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital/update.sh
chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital/checker.sh
chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital/skin.sh
sleep 2
/home/htpc/.config/openbox/checker.sh
else   # If Kodi is running, then....
echo ""
fi
sleep 1
done
done &
