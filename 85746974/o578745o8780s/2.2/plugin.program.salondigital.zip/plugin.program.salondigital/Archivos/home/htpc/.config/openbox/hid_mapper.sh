#!/bin/bash
sleep 3
cd /usr/src/HID_linux_xbmc_driver
./hid_mapper --lookup-id --manufacturer '1241' --product 'e000' --map /home/htpc/.salondigital/holtek_mce.map
