#!/bin/bash
sleep 5
wget -N --directory-prefix=/home/htpc/.config/openbox "https://googledrive.com/host/0B9ulaH2MCEtdSW1maDIyUWVRalE"
sleep 1
sudo mv /home/htpc/.config/openbox/0B9ulaH2MCEtdSW1maDIyUWVRalE /home/htpc/.config/openbox/version.txt
sleep 1
if grep -m1 2.2.0 "/home/htpc/.config/openbox/version.txt"
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando actualizaciones","message":"Está actualizado a la última versión"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando actualizaciones","message":"Está actualizado a la última versión"}}' http://localhost:8080/jsonrpc
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Por favor, descárgesela y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Por favor, descárgesela y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Por favor, descárgesela y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Por favor, descárgesela y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Por favor, descárgesela y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
if test -f "/home/htpc/Actualizaciones/plugin.program.salondigital.zip"
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital
sleep 1
unzip /home/htpc/Actualizaciones/plugin.program.salondigital.zip -d /home/htpc/.kodi/addons
sleep 1
sudo chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital
sleep 1
sudo sh /home/htpc/.kodi/addons/plugin.program.salondigital/update.sh
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Por favor, descargue la actualización y cópiela a la carpeta Actualizaciones"}}' http://localhost:8080/jsonrpc
fi
fi
