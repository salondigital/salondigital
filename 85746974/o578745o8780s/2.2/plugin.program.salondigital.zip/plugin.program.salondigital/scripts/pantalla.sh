#! /bin/bash
sudo systemctl enable LCDd
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Encendiendo pantalla","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Encendiendo pantalla","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo systemctl start LCDd
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Encendiendo pantalla","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Encendiendo pantalla","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo mv root /var/spool/cron/crontabs
sleep 1
sudo rm -rf /home/htpc/.kodi/userdata/addon_data/script.xbmc.lcdproc
sudo rm -rf /home/htpc/.kodi/addons/script.xbmc.lcdproc
sleep 1
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/lcd/addons/script.xbmc.lcdproc /home/htpc/.kodi/addons
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/lcd/userdata/script.xbmc.lcdproc /home/htpc/.kodi/userdata/addon_data
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Pantalla encendida","message":"Reiniciando equipo..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Pantalla encendida","message":""Reiniciando equipo..."}}' http://localhost:8080/jsonrpc
sudo reboot
