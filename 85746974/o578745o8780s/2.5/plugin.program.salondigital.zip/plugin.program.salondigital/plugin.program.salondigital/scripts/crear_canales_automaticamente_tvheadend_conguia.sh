#!/bin/bash
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando lista de canales","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 ~/Descargas
sudo chmod -R 777 /tmp
###BORRAMOS CARPETA PREVIA DE BACKUP Y EPG###
sudo rm -rf ~/epg
sudo rm -rf ~/Descargas/tvheadend_backup
###CREAMOS LA NUEVA Y LA DE LA EPG, BORRAMOS POSIBLES CARPETAS ANTIGUAS Y DESCOMPRIMOS EL TAR###
sudo mkdir ~/epg
sudo mkdir ~/Descargas/tvheadend_backup
sudo mkdir ~/Descargas/tvheadend_nuevo
sudo chmod -R 777 ~/Descargas/tvheadend_nuevo
sudo rm -rf ~/Descargas/channel
sudo rm -rf ~/Descargas/input
sudo rm -rf ~/Descargas/epggrab
sudo rm -rf ~/Descargas/Picons
###DESCARGAMOS LA ÚLTIMA LISTA DE CANALES###
wget "https://github.com/salondigital/salondigital/raw/master/8850/tvheadend.tar.xz" -P /home/htpc/Descargas
sleep 2
tar -xf ~/Descargas/tvheadend.tar.xz -C ~/Descargas/tvheadend_nuevo
###PERMISOS A LA CARPETA###
sudo chmod -R 777 ~/Descargas
###COPIAMOS LOS ARCHIVOS ANTIGUOS A MODO DE BACKUP####
sudo cp -R /home/hts/.hts/tvheadend/channel ~/Descargas/tvheadend_backup
sudo cp -R /home/hts/.hts/tvheadend/epggrab ~/Descargas/tvheadend_backup
sudo cp -R /home/hts/.hts/tvheadend/input ~/Descargas/tvheadend_backup
sudo cp -R ~/Picons ~/Descargas/tvheadend_backup
sudo chmod -R 777 ~/Descargas
####ELIMINAMOS LOS ARCHIVOS ANTIGUOS####
sudo rm -rf /usr/bin/tv_grab_movistar-spain
sudo rm -rf /home/hts/.hts/tvheadend/channel
sudo rm -rf /home/hts/.hts/tvheadend/epggrab
sudo rm -rf /home/hts/.hts/tvheadend/input
sudo rm -rf /home/hts/.hts/tvheadend/epgdb.v2
sudo rm -rf ~/Picons
###COPIAMOS LOS NUEVOS ARCHIVOS####
sudo cp -R ~/Descargas/tvheadend_nuevo/tv_grab_movistar-spain /usr/bin
sudo cp -R ~/Descargas/tvheadend_nuevo/channel /home/hts/.hts/tvheadend
sudo cp -R ~/Descargas/tvheadend_nuevo/epggrab /home/hts/.hts/tvheadend
sudo cp -R ~/Descargas/tvheadend_nuevo/input /home/hts/.hts/tvheadend
sudo cp -R ~/Descargas/tvheadend_nuevo/Picons ~/
###BORRAMOS LOS ARCHIVOS DESCOMPRIMIDOS Y TEMPORALES###
sudo rm -rf ~/Descargas/tvheadend_nuevo
##ESTABLECEMOS PERMISOS Y REINCIIAMOS TVHEADEND
sudo chown -R root:root /home/hts/.hts/tvheadend/channel
sudo chmod -R 777 /home/hts/.hts/tvheadend/channel
sudo chown -R root:root /home/hts/.hts/tvheadend/epggrab
sudo chmod -R 777 /home/hts/.hts/tvheadend/epggrab
sudo chown -R root:root /home/hts/.hts/tvheadend/input
sudo chmod -R 777 /home/hts/.hts/tvheadend/input
sudo chmod +x /usr/bin/tv_grab_movistar-spain
sudo chmod -R 777 /usr/bin/tv_grab_movistar-spain
sudo chmod -R 777 ~/epg
tar -czvf ~/Descargas/tvheadend_backup.tar.xz -C ~/Descargas/tvheadend_backup .
#tar -cJf tvheadend_backup.tar.xz ~/Descargas/tvheadend_backup
sudo chmod -R 777 ~/Descargas
sudo rm -rf ~/Descargas/tvheadend_backup
sudo rm -rf ~/Descargas/tvheadend_nuevo
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/channel
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/epggrab
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/input
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/Picons
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/tv_grab_movistar-spain
####CREA UN TAR.XZ CON EL BACKUP DE TVHEADEND###
/usr/bin/sudo service tvheadend restart
####BORRAMOS EL TVHEADEND DESCARGADO###
sudo rm -rf /home/htpc/Descargas/tvheadend.tar.xz
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Canales actualizados!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Canales actualizados!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Canales actualizados!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Canales actualizados!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Canales actualizados!","message":""}}' http://localhost:8080/jsonrpc
