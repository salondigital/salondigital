#!/bin/bash
file="/home/htpc/Descargas/tvheadend_backup.tar.xz"
if [ -f "$file" ]
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de tvheadend...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /tmp
###BORRAMOS CARPETA PREVIA DE BACKUP Y EPG###
sudo rm -rf ~/epg
sudo rm -rf ~/Descargas/tvheadend_backup
###CREAMOS LA NUEVA Y LA DE LA EPG, BORRAMOS POSIBLES CARPETAS ANTIGUAS Y DESCOMPRIMOS EL TAR###
sudo mkdir ~/epg
sudo mkdir ~/Descargas/tvheadend_backup
sudo chmod -R 777 ~/Descargas/tvheadend_backup
###PERMISOS A LA CARPETA###
sudo chmod -R 777 ~/Descargas
###COPIAMOS LOS ARCHIVOS ANTIGUOS A MODO DE BACKUP####
sudo cp -R /home/hts/.hts/tvheadend/channel ~/Descargas/tvheadend_backup
sudo cp -R /home/hts/.hts/tvheadend/epggrab ~/Descargas/tvheadend_backup
sudo cp -R /home/hts/.hts/tvheadend/input ~/Descargas/tvheadend_backup
sudo cp -R /usr/bin/tv_grab_movistar-spain ~/Descargas/tvheadend_backup
sudo chmod -R 777 ~/Descargas
##HACEMOS LA COPIA
tar -czvf ~/Descargas/tvheadend_backup.tar.xz -C ~/Descargas/tvheadend_backup .
sudo chmod -R 777 ~/Descargas
sudo rm -rf ~/Descargas/tvheadend_backup
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de tvheadend realizada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de tvheadend realizada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de tvheadend realizada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de tvheadend realizada!","message":""}}' http://localhost:8080/jsonrpc
fi
