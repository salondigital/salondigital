#! /bin/bash

space=`df / | awk 'NR==2 {print $4}'`

    if [ "$space" -gt 6048576 ] ; then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre mayor de 6GB","message":"Continuando con la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
      else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando espacio libre en disco","message":"No apague el equipo"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Cancelando la actualización"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
/usr/bin/sudo killall -9 update.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Espacio libre menor de 6GB","message":"Reiniciando"}}' http://localhost:8080/jsonrpc
sleep 1
sudo systemctl stop LCDd
killall -9 start.sh &
killall boblightd &
killall -9 lirc &
killall -9 kodi.bin &
/usr/bin/sudo shutdown -r now
fi
