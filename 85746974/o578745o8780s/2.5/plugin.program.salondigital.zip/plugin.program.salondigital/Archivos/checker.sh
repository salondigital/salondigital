#!/bin/bash
sleep 5
wget -N --directory-prefix=/home/htpc/.config/openbox "https://github.com/salondigital/salondigital/raw/master/version.txt"
sleep 1
if grep -m1 2.5.0 "/home/htpc/.config/openbox/version.txt"
then
""
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hay una nueva actualización!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
if test -f "/home/htpc/Actualizaciones/plugin.program.salondigital.zip"
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP encontrado!","message":"Instalando actualización, por favor espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital
sleep 1
unzip /home/htpc/Actualizaciones/plugin.program.salondigital.zip -d /home/htpc/.kodi/addons
sleep 1
sudo chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital
sleep 1
sudo sh /home/htpc/.kodi/addons/plugin.program.salondigital/update.sh
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Archivo ZIP NO encontrado!","message":"Vaya a Programas --> SalonDigital Updater y descargue el update"}}' http://localhost:8080/jsonrpc
fi
fi
