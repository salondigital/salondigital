#! /bin/bash
chromepid=$(pidof chrome)
if [ -z $chromepid ]; then # checks if chrome is running if not...
/usr/bin/sudo /etc/init.d/LCDd stop
sleep 1
killall -9 start.sh start2.sh 
sleep 1
sudo hyperion-remote -c black && sleep 2 && sudo killall -9 hyperiond
sleep 1
killall -9 lirc
sleep 1
killall -9 kodi.bin
sleep 1
/usr/bin/sudo /etc/rc0.d/S01halt stop
else
echo ""
fi
