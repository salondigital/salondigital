#!/bin/bash
sudo hyperion-remote -c black && sleep 2 && sudo killall -9 hyperiond &
sleep 2
sudo pm-suspend
