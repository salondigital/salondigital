#! /bin/bash
sudo systemctl stop LCDd
killall -9 start.sh start2.sh  &
sudo hyperion-remote -c black && sleep 2 && sudo killall -9 hyperiond &
sleep 2
killall -9 lirc &
killall -9 kodi.bin &
###/usr/bin/sudo /etc/rc0.d/S01halt stop
sudo poweroff -f
