sudo service smbd restart &
nvidia-settings -l &
sudo rm -rf /home/htpc/.kodi/temp/xbmcup/plugin.video.torrenter &
/home/htpc/Documentos/Iniciar_boblightd.sh &
# /usr/bin/hyperiond /etc/hyperion.config.json >/dev/null 2>&1 &
/home/htpc/.config/openbox/gpu.sh &
chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital/update.sh &
chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital/checker.sh &
chmod -R 777 /home/htpc/.kodi/addons/plugin.program.salondigital/skin.sh &
/home/htpc/.config/openbox/start.sh &
cp -r /home/htpc/.config/openbox/Adwaita /usr/share/icons &
cp -r /home/htpc/.config/openbox/flix2kodi/strings.po /home/htpc/.kodi/addons/plugin.video.flix2kodi/resources/language/English &
cp -r /home/htpc/.config/openbox/flix2kodi/play.py /home/htpc/.kodi/addons/plugin.video.flix2kodi/resources &
vncserver -geometry 1268x720 &
#x11vnc -auth guess -forever -loop -noxdamage -repeat -rfbauth /home/htpc/.vnc/passwd -rfbport 5900 -shared &
udisks-glue &
xscreensaver &
unclutter -idle 0.1 -root &
### /home/htpc/wg++/xmltv/update.sh &
/etc/init.d/bluetooth start &
transmission-daemon &
sudo sh /home/htpc/.salondigital/epg/xmltv.sh &
sudo sh /home/htpc/.config/openbox/hid_mapper.sh &
/home/htpc/.salondigital/script_generar_asound
sleep 1
irexec
