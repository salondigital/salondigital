#! /bin/bash
/usr/bin/sudo /etc/init.d/LCDd stop
killall -9 start.sh start2.sh  &
sudo hyperion-remote -c black && sleep 2 && sudo killall -9 hyperiond &
sleep 2
killall -9 lirc &
killall -9 kodi.bin &
/usr/bin/sudo shutdown -r now
