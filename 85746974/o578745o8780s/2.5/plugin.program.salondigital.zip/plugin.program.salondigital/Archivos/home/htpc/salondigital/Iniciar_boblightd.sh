#! /bin/bash
$(lsusb -d 2341:0042 | awk -F '[ :]'  '{ print "/dev/bus/usb/"$2"/"$4 }' | xargs -I {} echo "./usbreset {}")
sleep 1
$(lsusb -d 2341:0043 | awk -F '[ :]'  '{ print "/dev/bus/usb/"$2"/"$4 }' | xargs -I {} echo "./usbreset {}")
sleep 1
/usr/bin/hyperiond /etc/hyperion.config.json >/dev/null 2>&1
