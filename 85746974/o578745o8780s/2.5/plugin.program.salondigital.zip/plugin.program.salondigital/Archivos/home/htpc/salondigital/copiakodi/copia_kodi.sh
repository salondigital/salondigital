#!/bin/bash
file="/home/htpc/Descargas/kodi_backup.tar.xz"
if [ -f "$file" ]
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Ya existe una copia de seguridad hecha","message":"Por favor, borrela antes de intentar hacer la copia de nuevo"}}' http://localhost:8080/jsonrpc
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Creando copia de TODO Kodi...","message":"Espere hasta nuevo aviso"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 ~/Descargas
sudo chmod -R 777 /tmp
###BORRAMOS CARPETA PREVIA DE BACKUP###
sudo rm -rf ~/Descargas/kodi_backup
###CREAMOS LA NUEVA Y LE DAMOS PERMISOS###
sudo mkdir ~/Descargas/kodi_backup
sudo chmod -R 777 ~/Descargas/kodi_backup
###COPIAMOS LOS ARCHIVOS ANTIGUOS A MODO DE BACKUP####
sudo cp -R /home/htpc/.kodi ~/Descargas/kodi_backup
sudo chmod -R 777 ~/Descargas
###CREAMOS EL TAR####
tar -czvf ~/Descargas/kodi_backup.tar.xz -C ~/Descargas/kodi_backup .
sudo chmod -R 777 ~/Descargas
sudo rm -rf ~/Descargas/kodi_backup
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de Kodi realizada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de Kodi realizada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de Kodi realizada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de Kodi realizada!","message":""}}' http://localhost:8080/jsonrpc
fi
