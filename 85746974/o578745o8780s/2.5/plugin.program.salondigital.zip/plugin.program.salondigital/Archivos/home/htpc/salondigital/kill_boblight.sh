#! /bin/bash
sudo systemctl stop LCDd
killall -9 start.sh start2.sh  &
sudo hyperion-remote -c black && sleep 2 && sudo killall -9 hyperiond &
killall -9 lirc &
killall -9 kodi.bin &
sudo poweroff -f
