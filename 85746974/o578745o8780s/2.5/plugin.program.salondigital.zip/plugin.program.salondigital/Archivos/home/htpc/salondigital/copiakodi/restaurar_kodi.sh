#!/bin/bash
file="/home/htpc/Descargas/kodi_backup.tar.xz"
if [ -f "$file" ]
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere al reinicio de Kodi"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 ~/Descargas
sudo mkdir ~/Descargas/kodi_backup
sudo chmod -R 777 ~/Descargas/kodi_backup
tar -xf ~/Descargas/kodi_backup.tar.xz -C ~/Descargas/kodi_backup
sudo chmod -R 777 ~/Descargas
####ELIMINAMOS LOS ARCHIVOS ANTIGUOS####
sudo rm -rf /home/htpc/.kodi
###COPIAMOS LOS NUEVOS ARCHIVOS####
sudo cp -R ~/Descargas/kodi_backup/.kodi /home/htpc
###BORRAMOS LOS ARCHIVOS DESCOMPRIMIDOS Y TEMPORALES###
sudo rm -rf ~/Descargas/kodi_backup
##ESTABLECEMOS PERMISOS Y REINCIIAMOS TVHEADEND
sudo chmod -R 777 ~/Descargas
sudo chmod -R 777 /home/htpc/.kodi
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":"Reiniciando Kodi..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":"Reiniciando Kodi..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":"Reiniciando Kodi..."}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":"Reiniciando Kodi..."}}' http://localhost:8080/jsonrpc
sudo killall -9 kodi.bin
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
fi
