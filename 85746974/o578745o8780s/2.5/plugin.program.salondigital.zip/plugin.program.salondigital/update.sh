#!/bin/bash

#################### COMPROBACIÓN DEL SO #######################################################

file=/home/htpc/.config/openbox/version.dat
minimumsize=70000
actualsize=$(wc -c <"$file")
if [ $actualsize -ge $minimumsize ]; then
    echo size is over $minimumsize bytes

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando el Sistema Operativo","message":"SalonDigital 64 bits"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Por favor, espere a que el equipo se reinicie automaticamente"}}' http://localhost:8080/jsonrpc
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Por favor, espere a que el equipo se reinicie automaticamente"}}' http://localhost:8080/jsonrpc
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Por favor, espere a que el equipo se reinicie automaticamente"}}' http://localhost:8080/jsonrpc
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Por favor, espere a que el equipo se reinicie automaticamente"}}' http://localhost:8080/jsonrpc
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Por favor, espere a que el equipo se reinicie automaticamente"}}' http://localhost:8080/jsonrpc
sleep 2
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Por favor, espere a que el equipo se reinicie automaticamente"}}' http://localhost:8080/jsonrpc
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Vaciando papelera de reciclaje"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Vaciando papelera de reciclaje"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Vaciando papelera de reciclaje"}}' http://localhost:8080/jsonrpc
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando el sistema, no apague el equipo","message":"Vaciando papelera de reciclaje"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.local/share/Trash
sleep 2
sudo sh /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/espaciolibre.sh
sleep 2

########################### PERMISOS DE ESCRITURA Y LECTURA DE LAS CARPETAS DE KODI ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi/system
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /media/htpc/Datos
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.attract
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/icons
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /lib/firmware
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/Documentos
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"Espere al reinicio"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /etc/LCDd.conf
sudo rm -rf /usr/lib/x86_64-linux-gnu/libaacs.so.0
sudo rm -rf /usr/lib/x86_64-linux-gnu/libaacs.so.0.5.1
sleep 1
sudo ln -s /usr/lib/libmmbd.so.0 /usr/lib/libaacs.so.0
sudo ln -s /usr/lib/libmmbd.so.0 /usr/lib/libbdplus.so.0

########################### COPIA DE SEGURIDAD DEL MAPEO DEL MANDO ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"45%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /usr/share/kodi/system/keymapsbak
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"45%"}}' http://localhost:8080/jsonrpc
sudo mv /usr/share/kodi/system/keymaps /usr/share/kodi/system/keymapsbak
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"45%"}}' http://localhost:8080/jsonrpc
/usr/bin/sudo mv /usr/share/kodi/system/Lircmap.xml /usr/share/kodi/system/Lircmap.bak
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"45%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi/system/keymaps
sleep 1

########################### ACTUALIZAMOS LOS PAQUETES Y ARCHIVOS ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
sudo killall boblightd
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
wget -nv -N https://raw.githubusercontent.com/hyperion-project/hyperion/master/bin/install_hyperion.sh  && chmod +x /home/htpc/install_hyperion.sh && sudo sh /home/htpc/install_hyperion.sh HyperConInstall
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
sudo mkdir /home/htpc/.salondigital/hyperion
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.salondigital/hyperion
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
sudo cp -R /usr/share/hyperion/effects /home/htpc/.salondigital/hyperion
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.salondigital/hyperion
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"55%"}}' http://localhost:8080/jsonrpc
sleep 1


########## NUEVAS CARACTERISTICAS #########################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/kodi/addons/plugin.video.tvalacarta /home/htpc/.kodi/addons
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/kodi/addons/skin.eminence.2.mod/extras/icons/movistar.png /home/htpc/.kodi/addons/skin.eminence.2.mod/extras/icons
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/kodi/userdata /home/htpc/.kodi
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/Apagar.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/Apagar_mstech.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/boblight.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/Iniciar_boblightd.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/kill_boblight.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/reboot.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/suspender.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/Apagar.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/Apagar_mstech.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/boblight.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/Iniciar_boblightd.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/kill_boblight.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/reboot.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/suspender.sh /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/hyperion /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/salondigital/copiakodi /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/config/openbox /home/htpc/.config
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/makemkv/settings.conf /home/htpc/.MakeMKV
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/xvnc/xstartup /home/htpc/.vnc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/Documentos/boblight.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/Documentos/Iniciar_boblightd.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/Documentos/kill_boblight.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/home/htpc/Documentos /home/htpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/script.xbmc.boblight
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /usr/bin/hyperiond
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /usr/bin/hyperion-remote
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/usr/bin/hyperiond /usr/bin
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/usr/bin/hyperion-remote /usr/bin
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/userdata/addon_data/script.xbmc.boblight
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/Documentos/eminence.2.mod_0-255.zip
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/Documentos/eminence.2.mod_16-235.zip
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital/scripts/actualizar_tvheadend.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital/scripts/restaurar_tvheadend.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"65%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.salondigital/tvheadend


########################### RESTAURAMOS LOS ARCHIVOS DEL MANDO ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi/system
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi/system/keymaps
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70"}}' http://localhost:8080/jsonrpc
sudo rm -rf /usr/share/kodi/system/keymaps
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70"}}' http://localhost:8080/jsonrpc
sudo rm -rf /usr/share/kodi/system/Lircmap.xml
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70"}}' http://localhost:8080/jsonrpc
sudo mv /usr/share/kodi/system/keymapsbak /usr/share/kodi/system/keymaps
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"70"}}' http://localhost:8080/jsonrpc
sudo mv /usr/share/kodi/system/Lircmap.bak /usr/share/kodi/system/Lircmap.xml


########################### FINALIZAMOS DANDO DE NUEVO PERIMSOS ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/kodi
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /etc/pulse/pulse.pa
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.attract/emulators
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /tmp
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/bin/tv_grab_movistar-spain
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod +x /usr/bin/hyperion-remote
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod +x /usr/bin/hyperiond
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /media/htpc/Datos
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.attract
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/antimicro
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/google-chrome
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/m64.py
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/mame
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/mupen64plus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/openbox
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/PCSX2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.config/reicast
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.dolphin-emu
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.dolphin-emu-wii
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.mame
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.mess
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.openMSX
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.qjoypad3
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.raine
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.reicast
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.salondigital
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/Descargas
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/lib/games/PCSX2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/games/dolphin-emu
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/games/mame
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/games/mess
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/games/mupen64plus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/openmsx
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /usr/share/games/PCSX2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.ACEStream
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/addons/program.plexus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/addons/plugin.video.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/addons/repository.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/userdata/addon_data/plugin.video.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"85%"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/userdata/addon_data/program.plexus

########################### MODIFICAMOS EL UPDATE PARA QUE SALGA LA VERSIÓN CORRECTA ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"95%"}}' http://localhost:8080/jsonrpc
sudo mv /home/htpc/.kodi/addons/plugin.program.salondigital/update.sh /home/htpc/.kodi/addons/plugin.program.salondigital/update.bak
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"95%"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital/update.cfg
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Actualizando","message":"95%"}}' http://localhost:8080/jsonrpc
sudo cp -R /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos/updatefinalizado.cfg /home/htpc/.kodi/addons/plugin.program.salondigital/update.cfg

########################### ACTUALIZAMOS LA LISTA DE CANALES DE TVHEADEND ####################################


########################### BORRAMOS LOS TEMPORALES ####################################

curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital/Archivos
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.program.salondigital.zip
sleep 1
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/Actualizaciones/plugin.program.salondigital.zip
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/comprobadormd5.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/install_hyperion.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/sd.md5
sleep 10
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sudo killall -9 kodi.bin
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reiniciando equipo","message":"Por favor, espere"}}' http://localhost:8080/jsonrpc
sleep 17
sudo reboot
else
    echo size is under $minimumsize bytes
	curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Comprobando el Sistema Operativo","message":"El S.O no es SalonDigital, apagando..."}}' http://localhost:8080/jsonrpc
	sleep 4
	sudo /home/htpc/.salondigital/kill_boblight.sh
fi
