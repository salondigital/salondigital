#! /bin/bash
/home/htpc/.kodi/addons/plugin.program.salondigital/scripts/./skin.sh.x
