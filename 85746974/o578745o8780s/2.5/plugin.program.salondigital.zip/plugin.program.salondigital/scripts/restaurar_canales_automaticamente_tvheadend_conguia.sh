#!/bin/bash
file="/home/htpc/Descargas/tvheadend_backup.tar.xz"
if [ -f "$file" ]
then
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad detectada!","message":"Restaurando...espere por favor"}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 ~/Descargas
sudo mkdir ~/Descargas/tvheadend_backup
sudo chmod -R 777 ~/Descargas/tvheadend_backup
tar -xf ~/Descargas/tvheadend_backup.tar.xz -C ~/Descargas/tvheadend_backup
sudo chmod -R 777 ~/Descargas
####ELIMINAMOS LOS ARCHIVOS ANTIGUOS####
sudo rm -rf /home/hts/.hts/tvheadend/channel
sudo rm -rf /home/hts/.hts/tvheadend/epggrab
sudo rm -rf /home/hts/.hts/tvheadend/input
sudo rm -rf /home/hts/.hts/tvheadend/epgdb.v2
sudo rm -rf ~/Picons
###COPIAMOS LOS NUEVOS ARCHIVOS####
sudo cp -R ~/Descargas/tvheadend_backup/channel /home/hts/.hts/tvheadend
sudo cp -R ~/Descargas/tvheadend_backup/epggrab /home/hts/.hts/tvheadend
sudo cp -R ~/Descargas/tvheadend_backup/input /home/hts/.hts/tvheadend
sudo cp -R ~/Descargas/tvheadend_backup/Picons ~/
###BORRAMOS LOS ARCHIVOS DESCOMPRIMIDOS Y TEMPORALES###
sudo rm -rf ~/Descargas/tvheadend_backup
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/channel
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/epggrab
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/input
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/Picons
sudo rm -rf ~/.kodi/addons/plugin.program.salondigital/scripts/tv_grab_movistar-spain
##ESTABLECEMOS PERMISOS Y REINCIIAMOS TVHEADEND
sudo chown -R root:root /home/hts/.hts/tvheadend/channel
sudo chmod -R 777 /home/hts/.hts/tvheadend/channel
sudo chown -R root:root /home/hts/.hts/tvheadend/epggrab
sudo chmod -R 777 /home/hts/.hts/tvheadend/epggrab
sudo chown -R root:root /home/hts/.hts/tvheadend/input
sudo chmod -R 777 /home/hts/.hts/tvheadend/input
sudo chmod -R 777 ~/Descargas
/usr/bin/sudo service tvheadend restart
sleep 2
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":""}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Copia de seguridad restaurada!","message":""}}' http://localhost:8080/jsonrpc
else
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"No existe ninguna copia de seguridad","message":"Por favor, realice primero una copia de seguridad restaurable"}}' http://localhost:8080/jsonrpc
fi
