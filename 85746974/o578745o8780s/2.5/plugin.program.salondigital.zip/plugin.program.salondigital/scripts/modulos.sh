#!/bin/bash
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/plugin.video.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/program.plexus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/addons/repository.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/userdata/addon_data/plugin.video.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo rm -rf /home/htpc/.kodi/userdata/addon_data/program.plexus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.salondigital/modulosplexus/addons /home/htpc/.kodi
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Reparando modulos...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo cp -r /home/htpc/.salondigital/modulosplexus/userdata/addon_data /home/htpc/.kodi/userdata
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Por favor, espere...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/addons/program.plexus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Por favor, espere...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/addons/plugin.video.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Por favor, espere...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/addons/repository.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Por favor, espere...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/userdata/addon_data/plugin.video.plexus-streams
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"Por favor, espere...","message":"Por favor, espere..."}}' http://localhost:8080/jsonrpc
sudo chmod -R 777 /home/htpc/.kodi/userdata/addon_data/program.plexus
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Modulos reparados!","message":""}}' http://localhost:8080/jsonrpc
