#! /bin/bash
sudo rm -rf /home/htpc/.salondigital/Apagar.sh
sudo rm -rf /home/htpc/.salondigital/kill_boblight.sh
sudo rm -rf /home/htpc/Documentos/kill_boblight.sh
sudo cp -r /home/htpc/.salondigital/Apagarysuspender/Apagar.sh /home/htpc/.salondigital/Apagar.sh
sudo cp -r /home/htpc/.salondigital/Apagarysuspender/Apagar.sh /home/htpc/.salondigital/kill_boblight.sh
sudo cp -r /home/htpc/.salondigital/Apagarysuspender/Apagar.sh /home/htpc/Documentos/kill_boblight.sh
sudo chmod -R 777 /home/htpc/Documentos/kill_boblight.sh
sudo chmod -R 777 /home/htpc/.salondigital/Apagar.sh
sudo chmod -R 777 /home/htpc/.salondigital/kill_boblight.sh
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"id":1,"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"¡Hecho!","message":""}}' http://localhost:8080/jsonrpc
